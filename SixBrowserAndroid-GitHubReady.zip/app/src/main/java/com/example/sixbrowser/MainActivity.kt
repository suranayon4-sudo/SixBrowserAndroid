package com.example.sixbrowser

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat

class MainActivity : AppCompatActivity() {

    // GANTI 6 URL INI sesuai kebutuhan.
    private val urls = arrayOf(
        "https://example.com",
        "https://example.org",
        "https://example.net",
        "https://www.google.com",
        "https://www.bing.com",
        "https://www.wikipedia.org"
    )

    private val browsers = ArrayList<WebView>()

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)

        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
        }
        setContentView(root)

        // 2 kolom x 3 baris.
        for (i in 0 until 6) {
            val webView = createBrowser(urls[i])

            val row = i / 2
            val col = i % 2

            val params = FrameLayout.LayoutParams(
                0,
                0
            ).apply {
                leftMargin = 1
                rightMargin = 1
                topMargin = 1
                bottomMargin = 1
                // Posisi dan ukuran dihitung saat root berubah ukuran.
                width = FrameLayout.LayoutParams.MATCH_PARENT
                height = FrameLayout.LayoutParams.MATCH_PARENT
            }

            root.addView(webView, params)
            browsers.add(webView)

            webView.post {
                layoutBrowser(webView, row, col)
            }
        }

        root.viewTreeObserver.addOnGlobalLayoutListener {
            for (i in browsers.indices) {
                layoutBrowser(browsers[i], i / 2, i % 2)
            }
        }
    }

    private fun layoutBrowser(view: View, row: Int, col: Int) {
        val parent = view.parent as? View ?: return
        val w = parent.width
        val h = parent.height
        if (w <= 0 || h <= 0) return

        val cellW = w / 2
        val cellH = h / 3

        val lp = view.layoutParams as FrameLayout.LayoutParams
        lp.width = cellW - 2
        lp.height = cellH - 2
        lp.leftMargin = col * cellW + 1
        lp.topMargin = row * cellH + 1
        view.layoutParams = lp
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun createBrowser(url: String): WebView {
        return WebView(this).apply {
            setBackgroundColor(Color.WHITE)

            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.loadsImagesAutomatically = true
            settings.cacheMode = WebSettings.LOAD_DEFAULT
            settings.useWideViewPort = true
            settings.loadWithOverviewMode = false
            settings.builtInZoomControls = false
            settings.displayZoomControls = false
            settings.mediaPlaybackRequiresUserGesture = false

            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(
                    view: WebView,
                    request: android.webkit.WebResourceRequest
                ): Boolean {
                    return false
                }
            }
            webChromeClient = WebChromeClient()

            loadUrl(url)
        }
    }

    override fun onDestroy() {
        for (webView in browsers) {
            webView.stopLoading()
            webView.webChromeClient = null
            webView.webViewClient = WebViewClient()
            webView.destroy()
        }
        browsers.clear()
        super.onDestroy()
    }

    override fun onBackPressed() {
        // Tombol Back bekerja pada browser yang paling baru bisa mundur.
        for (i in browsers.indices.reversed()) {
            if (browsers[i].canGoBack()) {
                browsers[i].goBack()
                return
            }
        }
        super.onBackPressed()
    }
}
