# SixBrowserAndroid

Aplikasi Android dengan 6 WebView dalam layout 2 kolom x 3 baris.

## Yang perlu diketahui

- Enam panel browser tampil bersamaan.
- Setiap panel memiliki URL awal sendiri.
- JavaScript dan DOM Storage aktif.
- Navigasi halaman tetap berada di dalam WebView.
- Tombol Back mencoba mundur pada panel yang terakhir dapat mundur.

## Mengganti URL

Buka:

`app/src/main/java/com/example/sixbrowser/MainActivity.kt`

Cari:

`private val urls = arrayOf(...)`

Lalu ganti keenam URL sesuai kebutuhan.

## Build dari HP memakai GitHub Actions

1. Buat repository GitHub baru.
2. Upload seluruh isi project ini ke repository.
3. Pastikan branch utama bernama `main` atau `master`.
4. Buka tab **Actions**.
5. Pilih workflow **Build Android APK**.
6. Tekan **Run workflow**.
7. Setelah selesai, buka hasil workflow dan bagian **Artifacts**.
8. Download `SixBrowser-debug-apk`.
9. Ekstrak ZIP artifact lalu pasang `app-debug.apk` di Android.

## Catatan session/cookie

Enam WebView berada dalam satu proses Android. Karena itu, project ini **tidak menjamin isolasi cookie/session 100%** antar keenam panel. Jika kebutuhan utamanya adalah enam akun/login yang benar-benar independen, arsitekturnya perlu dibuat berbeda (misalnya proses/profile terpisah dengan batasan Android WebView).
