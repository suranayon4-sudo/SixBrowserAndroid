# Six Browser Android

Aplikasi Android dengan 6 WebView dalam layout 2 x 3.

## Session terpisah

Project ini memakai AndroidX WebKit Multi-Profile API. Setiap WebView diberi profile:

- browser_1
- browser_2
- browser_3
- browser_4
- browser_5
- browser_6

Profile WebView memiliki data browsing sendiri, termasuk cookie dan storage, jika WebView pada perangkat mendukung fitur MULTI_PROFILE.

## Build dari GitHub

1. Upload seluruh isi repository ini ke GitHub.
2. Buka tab **Actions**.
3. Pilih workflow **Build Android APK**.
4. Jalankan **Run workflow**.
5. Setelah selesai, buka hasil workflow.
6. Download artifact **SixBrowser-debug-apk**.
7. Extract ZIP artifact dan install `app-debug.apk`.

Catatan: jangan upload ZIP lama Electron. Upload isi project Android ini.
