plugins {
    id("com.android.application")
}

android {
    namespace = "com.example.sixbrowser"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.sixbrowser"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.webkit:webkit:1.16.0")
}
