package com.example.sixbrowser;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private static final String HOME = "https://www.google.com";
    private final WebView[] webViews = new WebView[6];
    private boolean multiProfileSupported = false;

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable bg(int color, float radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        multiProfileSupported = WebViewFeature.isFeatureSupported(
                WebViewFeature.MULTI_PROFILE
        );

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(11, 17, 32));

        TextView header = new TextView(this);
        header.setText("Six Browser  •  6 session terpisah");
        header.setTextColor(Color.WHITE);
        header.setTextSize(16);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(14), 0, dp(14), 0);
        header.setBackgroundColor(Color.rgb(15, 23, 42));
        root.addView(header, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(52)
        ));

        if (!multiProfileSupported) {
            Toast.makeText(
                    this,
                    "WebView perangkat ini belum mendukung multi-profile. Session tidak dapat dipisahkan penuh.",
                    Toast.LENGTH_LONG
            ).show();
        }

        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(2);
        grid.setRowCount(3);
        grid.setPadding(dp(4), dp(4), dp(4), dp(4));

        LinearLayout.LayoutParams gridParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        );
        root.addView(grid, gridParams);

        for (int i = 0; i < 6; i++) {
            grid.addView(createBrowserCard(i));
        }

        setContentView(root);
    }

    @SuppressLint("SetJavaScriptEnabled")
    private View createBrowserCard(final int index) {
        final int id = index + 1;

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(3), dp(3), dp(3), dp(3));
        card.setBackground(bg(Color.rgb(30, 41, 59), 8));

        GridLayout.LayoutParams cardParams = new GridLayout.LayoutParams();
        cardParams.width = 0;
        cardParams.height = 0;
        cardParams.columnSpec = GridLayout.spec(index % 2, 1, 1f);
        cardParams.rowSpec = GridLayout.spec(index / 2, 1, 1f);
        cardParams.setMargins(dp(3), dp(3), dp(3), dp(3));
        card.setLayoutParams(cardParams);

        TextView title = new TextView(this);
        title.setText("Browser " + id + "  •  Session " + id);
        title.setTextColor(Color.WHITE);
        title.setTextSize(12);
        title.setGravity(Gravity.CENTER_VERTICAL);
        title.setPadding(dp(7), 0, dp(7), 0);
        title.setBackgroundColor(Color.rgb(51, 65, 85));
        card.addView(title, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(28)
        ));

        // Compact navigation bar: arrows are hidden to give the URL field more room.
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);

        Button reload = smallButton("↻");
        Button home = smallButton("⌂");
        Button go = smallButton("GO");

        EditText address = new EditText(this);
        address.setSingleLine(true);
        address.setText(HOME);
        address.setTextColor(Color.WHITE);
        address.setTextSize(14);
        address.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        address.setPadding(dp(7), 0, dp(7), 0);
        address.setBackground(bg(Color.rgb(15, 23, 42), 7));

        bar.addView(reload, buttonParams());
        bar.addView(home, buttonParams());
        bar.addView(address, new LinearLayout.LayoutParams(0, dp(42), 1f));
        bar.addView(go, buttonParams());
        card.addView(bar);

        WebView webView = new WebView(this);
        webViews[index] = webView;

        // Each WebView gets its own WebView Profile.
        // Profiles have separate browsing data, including cookies and storage.
        if (multiProfileSupported) {
            try {
                WebViewCompat.setProfile(webView, "browser_" + id);
            } catch (Exception ignored) {
                Toast.makeText(
                        this,
                        "Profile Browser " + id + " tidak tersedia pada WebView perangkat.",
                        Toast.LENGTH_SHORT
                ).show();
            }
        }

        WebView.setWebContentsDebuggingEnabled(false);
        webView.setBackgroundColor(Color.WHITE);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setDatabaseEnabled(true);
        webView.getSettings().setSupportZoom(true);
        webView.getSettings().setBuiltInZoomControls(true);
        webView.getSettings().setDisplayZoomControls(false);
        webView.setWebChromeClient(new WebChromeClient());

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return false;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                address.setText(url);
                title.setText(
                        "Browser " + id + "  •  " +
                        (multiProfileSupported ? "Session " + id : "Session bersama")
                );
            }
        });

        View.OnClickListener navigateHome = v -> webView.loadUrl(HOME);
        home.setOnClickListener(navigateHome);
        reload.setOnClickListener(v -> webView.reload());
        View.OnClickListener navigate = v -> {
            String text = address.getText().toString().trim();
            if (text.isEmpty()) return;

            String url;
            if (text.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*")) {
                url = text;
            } else if (text.contains(".") && !text.contains(" ")) {
                url = "https://" + text;
            } else {
                url = "https://www.google.com/search?q=" +
                        android.net.Uri.encode(text);
            }
            webView.loadUrl(url);
        };

        go.setOnClickListener(navigate);
        address.setOnEditorActionListener((v, actionId, event) -> {
            navigate.onClick(v);
            return true;
        });

        LinearLayout.LayoutParams webParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        );
        webParams.topMargin = dp(3);
        card.addView(webView, webParams);

        webView.loadUrl(HOME);

        return card;
    }

    private Button smallButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(11);
        b.setAllCaps(false);
        b.setPadding(0, 0, 0, 0);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setBackground(bg(Color.rgb(37, 99, 235), 6));
        return b;
    }

    private LinearLayout.LayoutParams buttonParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                dp(40), dp(40)
        );
        p.setMargins(dp(1), 0, dp(1), 0);
        return p;
    }

    @Override
    public void onBackPressed() {
        // Back button controls the focused browser if possible.
        for (WebView webView : webViews) {
            if (webView != null && webView.canGoBack()) {
                webView.goBack();
                return;
            }
        }
        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        for (WebView webView : webViews) {
            if (webView != null) {
                webView.stopLoading();
                webView.destroy();
            }
        }
        super.onDestroy();
    }
}
