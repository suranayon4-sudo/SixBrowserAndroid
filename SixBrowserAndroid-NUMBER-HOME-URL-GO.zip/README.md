# SixBrowserAndroid

Six Browser Android — 6 sesi WebView terpisah dalam layout 2x3.

## UI
- Header setiap browser: nomor, Browser 1–6, dan domain aktif.
- Kontrol sederhana: back, forward, reload, home, URL, GO.
- Tidak ada tombol minimize/maximize/close kecil di sisi tab agar area browser tidak sempit.
- Tombol bawah B1–B6 dan Reset.

## Build
- Android Gradle Plugin 8.8.2
- Gradle 8.10.2 (dipasang oleh GitHub Actions)
- JDK 17
- compileSdk 35
- minSdk 24
- targetSdk 35
