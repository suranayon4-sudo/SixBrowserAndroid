package com.example.sixbrowser;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

public class MainActivity extends AppCompatActivity {
    private static final String HOME = "https://www.google.com";
    private final WebView[] webViews = new WebView[6];
    private final LinearLayout[] cards = new LinearLayout[6];
    private boolean multiProfileSupported = false;
    private int activeBrowser = 0;

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable bg(int color, float radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }

    private GradientDrawable strokeBg(int fill, int stroke, float radius) {
        GradientDrawable d = bg(fill, radius);
        d.setStroke(dp(1), stroke);
        return d;
    }

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        multiProfileSupported = WebViewFeature.isFeatureSupported(
                WebViewFeature.MULTI_PROFILE
        );

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(9, 16, 31));

        TextView header = new TextView(this);
        header.setText("Six Browser  •  6 session terpisah");
        header.setTextColor(Color.WHITE);
        header.setTextSize(16);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(14), 0, dp(14), 0);
        header.setBackgroundColor(Color.rgb(15, 23, 42));
        root.addView(header, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(48)
        ));

        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(2);
        grid.setRowCount(3);
        grid.setPadding(dp(3), dp(3), dp(3), dp(3));
        root.addView(grid, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ));

        for (int i = 0; i < 6; i++) {
            grid.addView(createBrowserCard(i));
        }

        // Floating tab selector like a desktop/browser tab strip.
        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        tabs.setGravity(Gravity.CENTER);
        tabs.setPadding(dp(5), dp(5), dp(5), dp(5));
        tabs.setBackground(bg(Color.rgb(31, 41, 55), 12));

        for (int i = 0; i < 6; i++) {
            final int index = i;
            Button tab = new Button(this);
            tab.setText("B" + (i + 1));
            tab.setTextSize(10);
            tab.setTextColor(Color.WHITE);
            tab.setAllCaps(false);
            tab.setPadding(0, 0, 0, 0);
            tab.setMinWidth(0);
            tab.setMinimumWidth(0);
            tab.setBackground(bg(i == 0 ? Color.rgb(37, 99, 235) : Color.rgb(55, 65, 81), 6));
            LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(dp(38), dp(32));
            tp.setMargins(dp(2), 0, dp(2), 0);
            tabs.addView(tab, tp);
            tab.setOnClickListener(v -> focusBrowser(index));
        }

        Button reset = new Button(this);
        reset.setText("↻ Reset");
        reset.setTextSize(10);
        reset.setTextColor(Color.WHITE);
        reset.setAllCaps(false);
        reset.setPadding(0, 0, 0, 0);
        reset.setMinWidth(0);
        reset.setMinimumWidth(0);
        reset.setBackground(bg(Color.rgb(124, 58, 237), 7));
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(dp(68), dp(32));
        rp.setMargins(dp(5), 0, 0, 0);
        tabs.addView(reset, rp);
        reset.setOnClickListener(v -> {
            for (WebView w : webViews) {
                if (w != null) w.loadUrl(HOME);
            }
            focusBrowser(0);
        });

        root.addView(tabs, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(42)
        ));

        if (!multiProfileSupported) {
            Toast.makeText(
                    this,
                    "WebView perangkat ini belum mendukung multi-profile. Session tidak dapat dipisahkan penuh.",
                    Toast.LENGTH_LONG
            ).show();
        }

        setContentView(root);
    }

    @SuppressLint("SetJavaScriptEnabled")
    private View createBrowserCard(final int index) {
        final int id = index + 1;

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(2), dp(2), dp(2), dp(2));
        card.setBackground(strokeBg(Color.rgb(18, 28, 45), Color.rgb(71, 85, 105), 6));
        cards[index] = card;

        GridLayout.LayoutParams cardParams = new GridLayout.LayoutParams();
        cardParams.width = 0;
        cardParams.height = 0;
        cardParams.columnSpec = GridLayout.spec(index % 2, 1, 1f);
        cardParams.rowSpec = GridLayout.spec(index / 2, 1, 1f);
        cardParams.setMargins(dp(2), dp(2), dp(2), dp(2));
        card.setLayoutParams(cardParams);

        // Browser tab header: number + current site + window controls.
        LinearLayout tabHeader = new LinearLayout(this);
        tabHeader.setOrientation(LinearLayout.HORIZONTAL);
        tabHeader.setGravity(Gravity.CENTER_VERTICAL);
        tabHeader.setPadding(dp(4), 0, dp(2), 0);
        tabHeader.setBackground(bg(Color.rgb(28, 47, 72), 4));

        TextView number = new TextView(this);
        number.setText(String.valueOf(id));
        number.setTextColor(Color.WHITE);
        number.setTextSize(10);
        number.setGravity(Gravity.CENTER);
        number.setBackground(bg(Color.rgb(37, 99, 235), 4));
        tabHeader.addView(number, new LinearLayout.LayoutParams(dp(22), dp(22)));

        TextView title = new TextView(this);
        title.setText("Browser " + id + " • " + hostFor(HOME));
        title.setTextColor(Color.WHITE);
        title.setTextSize(10);
        title.setGravity(Gravity.CENTER_VERTICAL);
        title.setSingleLine(true);
        title.setEllipsize(android.text.TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(0, dp(28), 1f);
        titleParams.setMargins(dp(5), 0, dp(3), 0);
        tabHeader.addView(title, titleParams);

        Button minimize = tinyWindowButton("−");
        Button maximize = tinyWindowButton("□");
        Button close = tinyWindowButton("×");
        tabHeader.addView(minimize, windowParams());
        tabHeader.addView(maximize, windowParams());
        tabHeader.addView(close, windowParams());

        card.addView(tabHeader, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(28)
        ));

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(1), 0, dp(1), 0);

        Button back = navButton("←");
        Button forward = navButton("→");
        Button reload = navButton("↻");
        Button home = navButton("⌂");
        Button go = navButton("GO");

        EditText address = new EditText(this);
        address.setSingleLine(true);
        address.setText(HOME);
        address.setTextColor(Color.rgb(20, 28, 40));
        address.setHintTextColor(Color.GRAY);
        address.setTextSize(10);
        address.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        address.setPadding(dp(5), 0, dp(5), 0);
        address.setBackground(bg(Color.rgb(238, 242, 247), 4));

        bar.addView(back, compactButtonParams());
        bar.addView(forward, compactButtonParams());
        bar.addView(reload, compactButtonParams());
        bar.addView(home, compactButtonParams());
        bar.addView(address, new LinearLayout.LayoutParams(0, dp(30), 1f));
        bar.addView(go, compactButtonParams());
        card.addView(bar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(34)
        ));

        WebView webView = new WebView(this);
        webViews[index] = webView;
        webView.setBackgroundColor(Color.WHITE);

        if (multiProfileSupported) {
            try {
                WebViewCompat.setProfile(webView, "browser_" + id);
            } catch (Exception ignored) {
                Toast.makeText(
                        this,
                        "Profile Browser " + id + " tidak tersedia pada WebView perangkat.",
                        Toast.LENGTH_SHORT
                ).show();
            }
        }

        WebView.setWebContentsDebuggingEnabled(false);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setDatabaseEnabled(true);
        webView.getSettings().setSupportZoom(true);
        webView.getSettings().setBuiltInZoomControls(true);
        webView.getSettings().setDisplayZoomControls(false);
        webView.setWebChromeClient(new WebChromeClient());

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return false;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                address.setText(url);
                title.setText("Browser " + id + " • " + hostFor(url));
            }
        });

        back.setOnClickListener(v -> {
            if (webView.canGoBack()) webView.goBack();
        });
        forward.setOnClickListener(v -> {
            if (webView.canGoForward()) webView.goForward();
        });
        reload.setOnClickListener(v -> webView.reload());
        home.setOnClickListener(v -> webView.loadUrl(HOME));

        View.OnClickListener navigate = v -> {
            String text = address.getText().toString().trim();
            if (text.isEmpty()) return;

            String url;
            if (text.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*")) {
                url = text;
            } else if (text.contains(".") && !text.contains(" ")) {
                url = "https://" + text;
            } else {
                url = "https://www.google.com/search?q=" +
                        android.net.Uri.encode(text);
            }
            webView.loadUrl(url);
        };

        go.setOnClickListener(navigate);
        address.setOnEditorActionListener((v, actionId, event) -> {
            navigate.onClick(v);
            return true;
        });

        // Window-style controls keep the look of the reference without changing
        // the six-session browser behavior.
        minimize.setOnClickListener(v -> {
            if (webView.getVisibility() == View.VISIBLE) {
                webView.setVisibility(View.GONE);
            } else {
                webView.setVisibility(View.VISIBLE);
            }
        });

        maximize.setOnClickListener(v -> focusBrowser(index));

        close.setOnClickListener(v -> {
            webView.loadUrl(HOME);
            focusBrowser(index);
        });

        LinearLayout.LayoutParams webParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        );
        webParams.topMargin = dp(2);
        card.addView(webView, webParams);

        webView.loadUrl(HOME);
        return card;
    }

    private String hostFor(String url) {
        try {
            android.net.Uri uri = android.net.Uri.parse(url);
            String host = uri.getHost();
            return host == null ? "New Tab" : host;
        } catch (Exception e) {
            return "New Tab";
        }
    }

    private Button navButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(9);
        b.setAllCaps(false);
        b.setPadding(0, 0, 0, 0);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setBackground(bg(Color.rgb(37, 99, 235), 4));
        return b;
    }

    private Button tinyWindowButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(9);
        b.setAllCaps(false);
        b.setPadding(0, 0, 0, 0);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setBackground(bg(Color.rgb(43, 61, 82), 3));
        return b;
    }

    private LinearLayout.LayoutParams compactButtonParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(30), dp(30));
        p.setMargins(dp(1), 0, dp(1), 0);
        return p;
    }

    private LinearLayout.LayoutParams windowParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(22), dp(22));
        p.setMargins(dp(1), 0, dp(1), 0);
        return p;
    }

    private void focusBrowser(int index) {
        if (index < 0 || index >= webViews.length) return;
        activeBrowser = index;
        if (webViews[index] != null) {
            webViews[index].setVisibility(View.VISIBLE);
            webViews[index].requestFocus();
        }
        if (cards[index] != null) {
            cards[index].bringToFront();
        }
    }

    @Override
    public void onBackPressed() {
        WebView webView = webViews[activeBrowser];
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
            return;
        }
        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        for (WebView webView : webViews) {
            if (webView != null) {
                webView.stopLoading();
                webView.destroy();
            }
        }
        super.onDestroy();
    }
}
